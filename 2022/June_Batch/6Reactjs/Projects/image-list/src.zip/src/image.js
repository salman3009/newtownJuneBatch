import carOne from './assets/image/1car.png';
import carTwo from './assets/image/2car.png';
import carThree from './assets/image/3car.png';
import carFour from './assets/image/4car.png';

const image = [
    {
        src: carOne
    }, 
    {
        src: carTwo
    }, 
    {
        src: carThree
    },
    {
        src: carFour
    }
]
export default image;