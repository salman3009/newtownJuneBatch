const config = {
    baseUrl: 'https://jsonplaceholder.typicode.com/',
    endPoints:{
        users: 'users',
    }
};
export default config;