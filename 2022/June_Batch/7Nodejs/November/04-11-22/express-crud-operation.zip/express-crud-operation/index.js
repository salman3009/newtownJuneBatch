const express = require('express');
const app = express();
const employee= require('./mock.json');

app.get('/',(req,res)=>{
    res.status(200).json({
        message:"fetching data successfully",
        list:employee
    })
});


app.listen(8080,()=>{
    console.log("port is running");
})